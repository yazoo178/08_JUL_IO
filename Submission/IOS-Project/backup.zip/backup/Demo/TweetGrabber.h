//
//  TweetGrabber.h
//  Demo
//
//  Created by Will on 07/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IDataGrabber.h"

@interface TweetGrabber :  NSOperation<IDataGrabber>

@property (strong) NSString* currentCity;
-(id)initWithCurrentCity:(NSString*)city;

@end
