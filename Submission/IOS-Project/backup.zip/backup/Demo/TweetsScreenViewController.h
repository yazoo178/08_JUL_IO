//
//  TweetsScreenViewController.h
//  Demo
//
//  Created by acp16w on 06/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TweetsScreenViewController : UIViewController

- (IBAction)closewindow:(id)sender;
@end
