//
//  Tweet.h
//  Demo
//
//  Created by acp16w on 22/11/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tweet : NSObject

@property (strong) NSString* tweet;
@property (assign) BOOL sentiment;
@property (assign) int tweet_id;

@end
