//
//  TwitterSentiment.h
//  Demo
//
//  Created by acp16w on 22/11/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Tweet.h"

@interface TwitterSentiment : NSObject

@property (strong) NSMutableArray* tweetData;
-(void)addTweet:(Tweet*)tweet;

+(TwitterSentiment*)instance;
@end
