//
//  FavePlaceInserter.h
//  Demo
//
//  Created by Will on 15/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IDbInserter.h"
#import "DbAccess.h"

@interface FavePlaceInserter : NSObject<IDbInserter>


@end
