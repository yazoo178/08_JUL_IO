//
//  TwitterSentiment.m
//  Demo
//
//  Created by acp16w on 22/11/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import "TwitterSentiment.h"



@implementation TwitterSentiment

static TwitterSentiment* sentiment;

-(id)init{
    self = [super init];
    
    if(self){
        self.tweetData = [[NSMutableArray alloc]init];
    }
    
    return self;
}

-(void)addTweet:(Tweet*)tweet{
    [self.tweetData addObject:tweet];
}

+(TwitterSentiment*)instance{
    if(sentiment == nil){
        sentiment = [[TwitterSentiment alloc]init];
    }
    
    return sentiment;
}

@end
