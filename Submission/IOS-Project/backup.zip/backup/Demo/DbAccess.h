//
//  DbAccess.h
//  Demo
//
//  Created by Will on 08/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "DbTableCreator.h"

@interface DbAccess : NSObject

@property (strong, nonatomic) NSString* dbSourcePath;
@property (strong, nonatomic) DbTableCreator* dbCreator;

- (id) init __attribute__((unavailable("You cannot create a new instance of this object, use instance method instead")));
- (void)loaddb;
- (void)executeInsert:(NSString*)query;

+ (DbAccess *)instance;

@end
