//
//  ViewController.m
//  Demo
//
//  Created by Will on 30/09/2016.
//  Copyright © 2016 Will. All rights reserved.
//
//AIzaSyDMtrJXX1EDWF-GJL43btV3dueyQF5u_wo

#import "ViewController.h"
#import <GoogleMaps/GoogleMaps.h>
#import "MapMoveHandler.h"
#import <GooglePlacePicker/GooglePlacePicker.h>
#import "FavePlaceInserter.h"
#import "CloudViewController.h"
#import "TwitterSentiment.h"
@interface ViewController ()

@end

@implementation ViewController

CLLocationManager *_manager;
GMSMapView        *mapView;
MapMoveHandler    *MoveLogger;
GMSCameraPosition *camera;
GMSPlacesClient *_placesClient;


- (void)viewDidLoad {
    
    TwitterSentiment* sent = [TwitterSentiment instance];
    
    
    
    [super viewDidLoad];
    [self Init];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)Init{
    
    if([CLLocationManager locationServicesEnabled])
    {
        _inserter = [[FavePlaceInserter alloc]init];
        _manager = [[CLLocationManager alloc]init];
        _manager.desiredAccuracy = kCLLocationAccuracyKilometer;
        _manager.distanceFilter = 500;
        
        if([_manager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
            [_manager requestAlwaysAuthorization];
        }
             
        [_manager startUpdatingLocation];
    }
    
    _placesClient = [GMSPlacesClient sharedClient];
    
    
    //GMSCameraPosition *camera = [GMSCameraPosition cameraWithTarget:CLLocationCoordinate2DMake(0, 0) zoom: [self CalcZoom]];
    
    MoveLogger = [[MapMoveHandler alloc] init];
    
    [MoveLogger addMethodPointer:@"ZOOM_CHANGE" arg:^void(id val) { [self onZoomChange:val]; }];
    
    _manager.delegate = MoveLogger;
    
    self.view.autoresizesSubviews = YES;
    [self.view setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
     UIViewAutoresizingFlexibleHeight];
    
    mapView = [self gettMapView:camera];
    MoveLogger.middleView = mapView;
    MoveLogger.labelForCity = self.labelForCity;
    
    [self.middleView addSubview:mapView];
    [self.middleView bringSubviewToFront:mapView];

}

- (GMSMapView*) gettMapView:(GMSCameraPosition*)cam{
     GMSMapView* _mapView = [GMSMapView mapWithFrame:_middleView.bounds camera:camera];
    _mapView.settings.myLocationButton = NO;
    _mapView.settings.indoorPicker = NO;
    _mapView.delegate = MoveLogger;
    _mapView.myLocationEnabled = YES;
    _mapView.autoresizesSubviews = YES;
    
    [_mapView setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
     UIViewAutoresizingFlexibleHeight];
    return _mapView;
    
}

- (float) CalcZoom{
    float unit = 21 / self.zoom.maximumValue;
    return self.zoom.value * unit;
}

- (IBAction)zoomchange:(id)sender{
    [mapView animateToZoom:[self CalcZoom]];
}

- (void)onZoomChange:(id)val{
    if([val floatValue] <= 2.34855175f){
        self.zoom.value = 0;
    }
    else{
        self.zoom.value = ([val floatValue] / 21) * 100;
    }
}

- (IBAction)getCurrentPlace:(UIButton *)sender {
    CLLocationCoordinate2D center = CLLocationCoordinate2DMake(MoveLogger.lastLoc.coordinate.latitude, MoveLogger.lastLoc.coordinate.longitude);
    CLLocationCoordinate2D northEast = CLLocationCoordinate2DMake(center.latitude + 0.001, center.longitude + 0.001);
    CLLocationCoordinate2D southWest = CLLocationCoordinate2DMake(center.latitude - 0.001, center.longitude - 0.001);
    
    GMSCoordinateBounds *viewport = [[GMSCoordinateBounds alloc] initWithCoordinate:northEast
                                                                         coordinate:southWest];
    GMSPlacePickerConfig *config = [[GMSPlacePickerConfig alloc] initWithViewport:viewport];
    GMSPlacePicker* _placePicker = [[GMSPlacePicker alloc] initWithConfig:config];
    
    [_placePicker pickPlaceWithCallback:^(GMSPlace *place, NSError *error) {
        if (error != nil) {
            NSLog(@"Pick Place error %@", [error localizedDescription]);
            return;
        }
        
        if (place != nil) {
            [_inserter insertWithType:place];
           
        } else {
        }
    }];
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    CloudViewController* cont = [segue destinationViewController];
    cont.URL = self.URLSample.text;
    
}




@end


