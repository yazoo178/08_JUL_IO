//
//  Constants.h
//  Demo
//
//  Created by Will on 09/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject

extern NSString *const USER_REVIEW_TABLE_CREATOR;
extern NSString *const USER_FAVE_TABLE_CREATOR;

@end