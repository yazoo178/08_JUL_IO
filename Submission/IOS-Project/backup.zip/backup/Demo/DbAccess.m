//
//  DbAccess.m
//  Demo
//
//  Created by Will on 08/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import "DbAccess.h"
#import "Constants.h"

@implementation DbAccess
sqlite3* DB;
NSString* dbFullPath;
static DbAccess * dbAc = nil;

-(id)initWithPath:(NSString *)path dbCreator:(DbTableCreator *)creator{
    
    self = [super init];
    if(self){
        self.dbSourcePath = path;
        self.dbCreator = creator;
    }
    return self;
}

-(void)loaddb{
    NSString *docsDir;
    NSArray *dirPaths;
    
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = [dirPaths objectAtIndex:0];
    
    // Build the path to the database file
    dbFullPath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: self.dbSourcePath]];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if ([filemgr fileExistsAtPath: dbFullPath ] == NO) {
        const char *dbpath = [dbFullPath UTF8String];
        
        if (sqlite3_open(dbpath, &DB) == SQLITE_OK) {
            char *errMsg;
            
            for(NSString* item in self.dbCreator.dbCreators)
            {
                const char* sqlTableCreatorutf16 = [item UTF8String];
                sqlite3_exec(DB, sqlTableCreatorutf16, NULL, NULL, &errMsg);
            }
            sqlite3_close(DB);
        }
    }
}

-(void)executeInsert:(NSString *)query{
    const char *dbpath = [dbFullPath UTF8String];
    sqlite3_stmt  *statement;
    
    if(sqlite3_open(dbpath, &DB) == SQLITE_OK)
    {
        const char * utf16v = [query UTF8String];
        sqlite3_prepare_v2(DB, utf16v, -1, &statement, NULL);
        
        if(sqlite3_step(statement) == SQLITE_DONE){
            
        }
        
        sqlite3_finalize(statement);
        sqlite3_close(DB);
    }
}

+ (DbAccess*) instance{
        
    if(dbAc == nil){
        DbTableCreator* creator = [[DbTableCreator alloc]initDbCreator];
        [creator addDbStr:USER_REVIEW_TABLE_CREATOR];
        [creator addDbStr:USER_FAVE_TABLE_CREATOR];
        dbAc = [[DbAccess alloc]initWithPath:@"myCiti.db" dbCreator:creator];
        [dbAc loaddb];
    }
    
    return dbAc;
    
}
@end
