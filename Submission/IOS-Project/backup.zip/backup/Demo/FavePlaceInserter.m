//
//  FavePlaceInserter.m
//  Demo
//
//  Created by Will on 15/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import "FavePlaceInserter.h"
#import <GooglePlacePicker/GooglePlacePicker.h>

@implementation FavePlaceInserter

-(bool)insertWithType:(id)param{
    DbAccess* dbEx = [DbAccess instance];
    GMSPlace* place = param;
    
    NSString* inserter = [NSString stringWithFormat:@"INSERT INTO FAVEPLACES (GOOGLE_PLACE_ID, NAME, PHONE_NUMBER, WEBSITE, RATING) VALUES ('%@','%@','%@','%@', %@)", place.placeID, place.name, place.phoneNumber, place.website, [NSNumber numberWithFloat:place.rating]];
    
    
    inserter = [inserter stringByReplacingOccurrencesOfString:@"'(null)'" withString:@"NULL"]; //HACKY AND DANGEROUS as it will replace a name that happens to have 'null' in it
    
    [dbEx executeInsert:inserter];
    
    return YES;
}

@end
