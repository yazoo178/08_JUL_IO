//
//  GeneralMethods.m
//  Kappenball
//
//  Created by Will on 24/10/2016.
//  Copyright © 2016 acp16w. All rights reserved.
//

#import "GeneralMethods.h"

@implementation GeneralMethods

//Loops through all the subviews of a view specified
//Invokes the block on each view
//Recursivly goes through each child view
+ (void)processSubviewsRecur:(UIView *)view onFound:(void(^)(UIView*))found {
    
    NSArray *views = [view subviews];
    
    if ([views count] < 1) return;
    
    for (UIView *subview in views) {
        found(subview);
        //Recursive call, now loop all the sub views
        [self processSubviewsRecur:subview onFound:found];
    }
}

//Shrinks then grows a ui view
//Over a specified duration
//Callback when the whole process has completed
+(void)scaleThenRevert:(UIView *)view fromFloat:(CGFloat)from durationFloat:(CGFloat)duration onComplete:(void (^)())complete withRotate:(BOOL)rotate revertTo:(CGAffineTransform) revert{
    [UIView animateWithDuration:duration delay:0.0 options:UIViewAnimationOptionCurveLinear animations:^{
        CGAffineTransform shrink = CGAffineTransformMakeScale(from, from);
        
        view.transform = rotate ? CGAffineTransformConcat(shrink, CGAffineTransformRotate(view.transform, M_PI))
                                                          : shrink;
        
    }completion:^(BOOL finished){
        [UIView animateWithDuration:duration animations:^{
            
            view.transform = revert;
        } completion:^(BOOL finished){
            if(complete != nil)
            {
                complete();
            }
        }];
    }];
}

//Shrinks then grows a ui view
//Over a specified duration
//Callback when the whole process has completed
+(void)scaleAppear:(UIView *)view toFloat:(CGFloat)to durationFloat:(CGFloat)duration onComplete:(void (^)())complete revertTo:(CGAffineTransform) revert{
    [UIView animateWithDuration:duration delay:0.0 options:UIViewAnimationOptionCurveLinear animations:^{
        CGAffineTransform shrink = CGAffineTransformMakeScale(to, to);
        view.transform = shrink;
    }completion:^(BOOL finished){
        [UIView animateWithDuration:duration animations:^{
            
            view.transform = revert;
        } completion:^(BOOL finished){
            if(complete != nil)
            {
                complete();
            }
        }];
    }];
}

//Rotates a ui view forever
//with a specified duration to complete a 90 degree cycle
+(void)rotateRecur:(UIImageView*)view withDuration:(float)dur{
    [UIView animateWithDuration:dur delay:0 options:UIViewAnimationOptionCurveLinear  animations:^{
        view.transform = CGAffineTransformRotate(view.transform, M_PI / 2);
    }completion:^(BOOL finished){
        [self rotateRecur:view withDuration:dur];
    }];
}

@end
