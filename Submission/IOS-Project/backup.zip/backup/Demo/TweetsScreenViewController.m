//
//  TweetsScreenViewController.m
//  Demo
//
//  Created by acp16w on 06/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import "TweetsScreenViewController.h"
#import "TweetGrabber.h"

@interface TweetsScreenViewController ()

@end

@implementation TweetsScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // TweetGrabber* grab = [[TweetGrabber alloc]initWithCurrentCity:@"Sheffield"];
    //[grab GetTweetsForLocation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}


-(void) closewindow:(id)sender{
    [self dismissModalViewControllerAnimated:YES];
}

@end
