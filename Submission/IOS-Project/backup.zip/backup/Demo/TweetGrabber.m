//
//  TweetGrabber.m
//  Demo
//
//  Created by Will on 07/10/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import "TweetGrabber.h"

@implementation TweetGrabber

@synthesize resultData;

-(id) initWithCurrentCity:(NSString *)city{
    self = [super init];
    if(self){
        self.currentCity = city;
    }
    return self;
}

-(void)start{
    
    //SUSHANT
    //currentCity == the current user city
    //USE THIS TO GET TWEETS FOR THAT CITY
     self.resultData =[self getData];
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.completionBlock();
    });
}

-(NSString*)getData{
    
    return @"TWITTER DATA";
    
}


@end
