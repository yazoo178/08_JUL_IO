//
//  ViewController.h
//  Demo
//
//  Created by Will on 30/09/2016.
//  Copyright © 2016 Will. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>
#import "IDbInserter.h"
#import <GoogleMaps/GoogleMaps.h>


@interface ViewController : UIViewController<CLLocationManagerDelegate, GMSMapViewDelegate>

@property (weak) IBOutlet UIView *middleView;
@property (weak) IBOutlet UILabel *labelForCity;
@property (weak) IBOutlet UISlider *zoom;
@property (weak) IBOutlet UILabel *nearLocations;
@property (weak) IBOutlet UITextField* URLSample;

@property (strong) NSObject<IDbInserter>* inserter;

- (IBAction)zoomchange:(id)sender;
- (IBAction)showTweets:(id)sender;
- (IBAction)getCurrentPlace:(UIButton *)sender;
- (void)onZoomChange:(id)val;



@end

