//
//  CloudViewController.m
//  LionAndLamb
//
//  Created by Peter Jensen on 4/24/15.
//  Copyright (c) 2015 Peter Christian Jensen.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#import "CloudViewController.h"

#import "CloudLayoutOperation.h" // For <CloudLayoutOperationDelegate> protocol

#import "UIFont+CloudSettings.h" // For LALSettingsFont
#import "UIColor+CloudSettings.h" // For LALSettingsColor
#import "GeneralMethods.h"
#import "WebpageDataGrabber.h"

@interface CloudViewController () <CloudLayoutOperationDelegate>

///**
// A strong reference to the dictionary of words and their word counts
// */
//@property (nonatomic, strong) NSDictionary *cloudWords;
/**
 A strong reference to an array of UIColor cloud colors
 
 @note These colors are related to the currentColorPreference enum
 */
@property (nonatomic, strong) NSArray *cloudColors;
/**
 A strong reference to the current cloud font name
 */
@property (nonatomic, strong) NSString *cloudFontName;

@property (nonatomic, strong) CloudLayoutOperation* currentOperation;

@property (nonatomic, strong) NSOperationQueue* queue;

@property(nonatomic, strong) NSTimer* spinTimer;

@end

@implementation CloudViewController

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        // Custom initialization
        self.queue = [[NSOperationQueue alloc] init];
        self.queue.name = @"Cloud layout operation queue";
        self.queue.maxConcurrentOperationCount = 1;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self layoutCloudWords];
    
}

-(void)updateSpin:(NSTimer*)arg{
    NSMutableArray* arr = [[NSMutableArray alloc]init];
    [GeneralMethods processSubviewsRecur:self.view onFound:^(UIView* found){
        if([found isKindOfClass:UILabel.class]){
            [arr addObject:found];
        }
    }];
    if([arr count] > 0)
    {
        int num = (int)1 + arc4random() % ([arr count]-1+1);
        UILabel* selected = arr[num - 1];
        [GeneralMethods scaleThenRevert:selected fromFloat:1.0 durationFloat:0.5 onComplete:nil withRotate:YES revertTo:selected.transform];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [self.spinTimer invalidate];
    [self.queue cancelAllOperations];
}



- (void)insertWord:(NSString *)word pointSize:(CGFloat)pointSize color:(NSUInteger)color center:(CGPoint)center vertical:(BOOL)isVertical buzzin:(BOOL)isBuzzin
{
    UILabel *wordLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    
    wordLabel.text = word;
    wordLabel.textAlignment = NSTextAlignmentCenter;
    wordLabel.textColor = self.cloudColors[color < self.cloudColors.count ? color : 0];
    wordLabel.font = [UIFont fontWithName:self.cloudFontName size:pointSize];
    
    [wordLabel sizeToFit];
    
    // Round up size to even multiples to "align" frame without ofsetting center
    CGRect wordLabelRect = wordLabel.frame;
    wordLabelRect.size.width = ((NSInteger)((CGRectGetWidth(wordLabelRect) + 3) / 2)) * 2;
    wordLabelRect.size.height = ((NSInteger)((CGRectGetHeight(wordLabelRect) + 3) / 2)) * 2;
    wordLabel.frame = wordLabelRect;
    
    wordLabel.center = center;
    
    if (isVertical)
    {
        [GeneralMethods scaleAppear:wordLabel toFloat:2 durationFloat:0.5 onComplete:nil revertTo:CGAffineTransformMakeRotation(M_PI_2)];

    }
    
    else{
        [GeneralMethods scaleAppear:wordLabel toFloat:2 durationFloat:0.5 onComplete:nil revertTo:CGAffineTransformIdentity];

    }
    
    
    
    [self.view addSubview:wordLabel];
}


#pragma mark - Private methods

/**
 Remove all words from the cloud view
 */
- (void)removeCloudWords
{
    NSMutableArray *removableObjects = [[NSMutableArray alloc] init];
    
    // Remove cloud words (UILabels)
    
    for (id subview in self.view.subviews)
    {
        if ([subview isKindOfClass:[UILabel class]])
        {
            [removableObjects addObject:subview];
        }
    }
    
    [removableObjects makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
#ifdef DEBUG
    // Remove bounding boxes
    
    [removableObjects removeAllObjects];
    
    for (id sublayer in self.view.layer.sublayers)
    {
        if ([sublayer isKindOfClass:[CALayer class]] && ((CALayer *)sublayer).borderWidth && ![sublayer delegate])
        {
            [removableObjects addObject:sublayer];
        }
    }
    
    [removableObjects makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
#endif
}

- (void)layoutCloudWords
{
    
    [self.currentOperation cancel];
    [self removeCloudWords];
    
    self.cloudColors = [UIColor lal_colorsForPreferredColor:LALSettingsColorMustardRed];
    self.cloudFontName = [UIFont lal_fontNameForPreferredFont:LALSettingsFontAvenir];
    WebpageDataGrabber* grabber = [[WebpageDataGrabber alloc]initWithURL:self.URL];
    
    
    
    // Start a new cloud layout operation
    NSError* readError = NULL;
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"test" ofType:@"txt"];
    
    __block NSString* content = [NSString stringWithContentsOfFile:filepath
                                                  encoding:NSUTF8StringEncoding
                                                     error:&readError];
    
    
    NSMutableDictionary * myDict = [[NSMutableDictionary alloc]init];
    [self.queue addOperation:grabber];
    grabber.completionBlock = ^{
        
        content = grabber.resultData;
        NSRange   searchedRange = NSMakeRange(0, [content length]);
        
        NSError  *error = nil;
        
        NSRegularExpression* exp = [NSRegularExpression regularExpressionWithPattern:@"[A-Za-z]+" options:0 error:&error];
        
        NSArray* matches = [exp matchesInString:content options:0 range: searchedRange];
        
        for (NSTextCheckingResult* match in matches){
            NSString* matchText = [content substringWithRange:[match range]];
            matchText = [matchText lowercaseString];
            if([myDict objectForKey:matchText]){
                NSNumber *number = myDict[matchText];
                int value = [number intValue];
                number = [NSNumber numberWithInt:value + 1];
                myDict[matchText] = number;
                
            }
            else{
                [myDict setObject:[NSNumber numberWithInt:1] forKey:matchText];
            }
        }
        
        self.currentOperation = [[CloudLayoutOperation alloc] initWithCloudWords:myDict
                                                            forContainerWithSize:self.view.bounds.size
                                                                           scale:[[UIScreen mainScreen] scale]
                                                                        delegate:self];
        
        __weak CloudViewController *weakSelf = self;
        self.currentOperation.completionBlock = ^{
            [weakSelf startTimer];
        };
        
        [self.queue addOperation:self.currentOperation];
        
    };

    
    
    
}

-(void)startTimer{
    self.spinTimer  = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(updateSpin:) userInfo:nil repeats:YES];
}



@end
